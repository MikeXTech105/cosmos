import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

import { runReport } from "../../../services/reports/reportsService";
import { getApiErrorMessage } from "../../../utils/apiError";

const DEFAULT_META = {
  pageNumber: 1,
  pageSize: 25,
  totalCount: 0,
  totalPages: 1,
};

const initialReportState = {
  correlationId: null,
  data: null,
  error: null,
  filters: {},
  lastRunAt: null,
  meta: { ...DEFAULT_META },
  requestId: null,
  status: "idle",
};

const initialState = {
  byReport: {},
  exporting: {},
};

const getReportState = (state, reportKey) => {
  state.byReport[reportKey] ??= { ...initialReportState };

  return state.byReport[reportKey];
};

const normalizeMeta = (payload, data) => {
  const source = payload?.meta ?? data ?? {};

  return {
    pageNumber: Number(source.pageNumber) || DEFAULT_META.pageNumber,
    pageSize: Number(source.pageSize) || DEFAULT_META.pageSize,
    totalCount: Number(source.totalCount) || DEFAULT_META.totalCount,
    totalPages: Number(source.totalPages) || DEFAULT_META.totalPages,
  };
};

const normalizeReportResult = (payload) => {
  const data = payload?.data;
  const isPaged = data && typeof data === "object" && Array.isArray(data.items);

  return {
    correlationId: payload?.correlationId ?? null,
    data: isPaged ? data.items : data,
    meta: normalizeMeta(payload, data),
  };
};

export const runReportThunk = createAsyncThunk(
  "reports/runReport",
  async ({ endpoint, params = {}, reportKey }, { rejectWithValue, signal }) => {
    try {
      const payload = await runReport(endpoint, params, { signal });

      return {
        ...normalizeReportResult(payload),
        filters: params,
        reportKey,
      };
    } catch (error) {
      return rejectWithValue({
        correlationId:
          error?.apiError?.correlationId ??
          error?.response?.data?.correlationId ??
          null,
        message: getApiErrorMessage(error, "Unable to run report."),
        reportKey,
      });
    }
  },
);

const reportsSlice = createSlice({
  name: "reports",
  initialState,
  reducers: {
    clearAllReports: () => {
      return initialState;
    },
    clearReport: (state, action) => {
      delete state.byReport[action.payload];
      delete state.exporting[action.payload];
    },
    setReportExporting: (state, action) => {
      const { reportKey, value } = action.payload;

      state.exporting[reportKey] = Boolean(value);
    },
    setReportFilters: (state, action) => {
      const { filters, reportKey } = action.payload;
      const reportState = getReportState(state, reportKey);

      reportState.filters = { ...reportState.filters, ...filters };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(runReportThunk.pending, (state, action) => {
        const { params = {}, reportKey } = action.meta.arg;
        const reportState = getReportState(state, reportKey);

        reportState.error = null;
        reportState.filters = params;
        reportState.requestId = action.meta.requestId;
        reportState.status = "loading";
      })
      .addCase(runReportThunk.fulfilled, (state, action) => {
        const reportState = getReportState(state, action.payload.reportKey);

        if (reportState.requestId !== action.meta.requestId) {
          return;
        }

        reportState.correlationId = action.payload.correlationId;
        reportState.data = action.payload.data;
        reportState.error = null;
        reportState.filters = action.payload.filters;
        reportState.lastRunAt = new Date().toISOString();
        reportState.meta = action.payload.meta;
        reportState.requestId = null;
        reportState.status = "succeeded";
      })
      .addCase(runReportThunk.rejected, (state, action) => {
        const reportKey = action.payload?.reportKey ?? action.meta.arg.reportKey;
        const reportState = getReportState(state, reportKey);

        if (reportState.requestId !== action.meta.requestId) {
          return;
        }

        if (action.meta.aborted) {
          reportState.requestId = null;
          reportState.status = "idle";
          return;
        }

        reportState.correlationId = action.payload?.correlationId ?? null;
        reportState.error =
          action.payload?.message ?? action.error.message ?? "Unable to run report.";
        reportState.requestId = null;
        reportState.status = "failed";
      });
  },
});

export const {
  clearAllReports,
  clearReport,
  setReportExporting,
  setReportFilters,
} = reportsSlice.actions;

export default reportsSlice.reducer;
