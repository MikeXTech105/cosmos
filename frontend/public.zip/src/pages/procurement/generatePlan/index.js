export { default } from "./GeneratePlanPage";
