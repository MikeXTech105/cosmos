export { default } from "./PurchaseBillsPage";
