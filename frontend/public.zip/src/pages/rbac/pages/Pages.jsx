export { default } from "./PagesPage";
