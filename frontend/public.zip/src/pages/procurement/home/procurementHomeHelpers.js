const firstDefined = (record, keys) => {
  for (const key of keys) {
    if (record?.[key] !== undefined && record?.[key] !== null) {
      return record[key];
    }
  }

  return null;
};

export const getPlanningLineToOrder = (line) =>
  Number(
    firstDefined(line, [
      "finalQuantity",
      "toOrderQuantity",
      "calculatedSuggestedQuantity",
      "suggestedQuantity",
    ]),
  ) || 0;

export const getPlanningLineStock = (line) =>
  firstDefined(line, ["physicalStock", "stockTotal", "currentStock"]);

export const getPlanningLineReorderPoint = (line) =>
  firstDefined(line, ["reorderPoint"]);

export const getPlanningLineShortfall = (line) =>
  Number(firstDefined(line, ["shortage", "shortfall"])) || 0;

export const getPlanningLineCover = (line) =>
  firstDefined(line, [
    "coverDays",
    "stockCoverDays",
    "daysOfCover",
    "inventoryCoverDays",
  ]);

export const getPlanningLineStatus = (line) => {
  const toOrder = getPlanningLineToOrder(line);
  const shortage = getPlanningLineShortfall(line);
  const stock = Number(getPlanningLineStock(line));
  const reorderPoint = Number(getPlanningLineReorderPoint(line));

  if (toOrder > 0 || shortage > 0) {
    return { label: "Order now", tone: "red", rank: 0 };
  }

  if (
    Number.isFinite(stock) &&
    Number.isFinite(reorderPoint) &&
    reorderPoint > 0 &&
    stock <= reorderPoint * 1.1
  ) {
    return { label: "Watch", tone: "amber", rank: 1 };
  }

  return { label: "OK", tone: "emerald", rank: 2 };
};

export const sortPlanningLines = (lines) =>
  [...lines].sort((first, second) => {
    const statusDifference =
      getPlanningLineStatus(first).rank - getPlanningLineStatus(second).rank;

    if (statusDifference !== 0) {
      return statusDifference;
    }

    const shortageDifference =
      getPlanningLineShortfall(second) - getPlanningLineShortfall(first);

    if (shortageDifference !== 0) {
      return shortageDifference;
    }

    return getPlanningLineToOrder(second) - getPlanningLineToOrder(first);
  });

export const getCalculationSteps = (line) => [
  { key: "usage", label: "Avg daily usage", value: line?.averageDailyUsage },
  {
    key: "lead-time",
    label: "Lead time",
    suffix: "days",
    value: line?.leadTimeDays,
  },
  {
    key: "lead-demand",
    label: "Demand during lead time",
    value: line?.leadTimeDemand,
  },
  { key: "safety", label: "Safety stock", value: line?.safetyStock },
  { key: "reorder", label: "Reorder point", value: line?.reorderPoint },
  { key: "stock", label: "Stock total", value: getPlanningLineStock(line) },
  {
    key: "shortage",
    label: "Shortfall",
    value: firstDefined(line, ["shortage", "shortfall"]),
  },
  {
    key: "system",
    label: "System suggestion",
    value: firstDefined(line, [
      "calculatedSuggestedQuantity",
      "suggestedQuantity",
    ]),
  },
  { key: "to-order", label: "To order", value: getPlanningLineToOrder(line) },
];

