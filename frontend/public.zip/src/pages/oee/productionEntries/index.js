export { default } from "./OeeProductionEntriesPage";
