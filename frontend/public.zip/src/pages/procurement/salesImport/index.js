export { default } from "./SalesImportPage";
