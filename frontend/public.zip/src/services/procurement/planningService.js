import axiosInstance from "../../api/axios";
import { ENDPOINTS } from "../../api/endpoints";
import { unwrapResponse } from "../apiServiceUtils";
import {
  downloadFile,
  sanitizeProcurementListParams,
} from "./procurementServiceUtils";

const RUN_SORT_FIELDS = [
  "runNumber",
  "fromDate",
  "toDate",
  "status",
  "calculatedAt",
];
const LINE_SORT_FIELDS = [
  "itemCode",
  "itemName",
  "shortage",
  "finalQuantity",
];

export const planningService = {
  validate: async (payload) => {
    const response = await axiosInstance.post(
      ENDPOINTS.PP_PLAN_VALIDATE,
      payload,
    );
    return unwrapResponse(response);
  },
  preview: async (payload) => {
    const response = await axiosInstance.post(
      ENDPOINTS.PP_PLAN_PREVIEW,
      payload,
    );
    return unwrapResponse(response);
  },
  saveRun: async (payload) => {
    const response = await axiosInstance.post(ENDPOINTS.PP_PLAN_RUNS, payload);
    return unwrapResponse(response);
  },
  listRuns: async (params) => {
    const response = await axiosInstance.get(ENDPOINTS.PP_PLAN_RUNS, {
      params: sanitizeProcurementListParams(params, RUN_SORT_FIELDS),
    });
    return unwrapResponse(response);
  },
  getRun: async (id) => {
    const response = await axiosInstance.get(ENDPOINTS.PP_PLAN_RUN_BY_ID(id));
    return unwrapResponse(response);
  },
  getRunLines: async (id, params) => {
    const response = await axiosInstance.get(ENDPOINTS.PP_PLAN_RUN_LINES(id), {
      params: sanitizeProcurementListParams(params, LINE_SORT_FIELDS),
    });
    return unwrapResponse(response);
  },
  adjustLine: async (runId, lineId, payload) => {
    const response = await axiosInstance.patch(
      ENDPOINTS.PP_PLAN_RUN_LINE(runId, lineId),
      payload,
    );
    return unwrapResponse(response);
  },
  finalize: async (id) => {
    const response = await axiosInstance.post(
      ENDPOINTS.PP_PLAN_RUN_FINALIZE(id),
    );
    return unwrapResponse(response);
  },
  exportRun: (id) =>
    downloadFile(axiosInstance, {
      fallbackFilename: `procurement-plan-${id}.xlsx`,
      url: ENDPOINTS.PP_PLAN_RUN_EXPORT(id),
    }),
};
