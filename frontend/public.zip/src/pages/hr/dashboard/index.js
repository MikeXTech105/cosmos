export { default } from "./HrDashboardPage";
