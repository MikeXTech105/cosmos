import {
  SALES_INVOICE_STATUS,
  SALES_PAYMENT_STATUS,
} from "../pages/sales/invoices/invoiceHelpers";
import { PURCHASE_STATUS } from "../pages/purchase/purchaseHelpers";

export const REPORT_STATUS = {
  salesInvoice: SALES_INVOICE_STATUS,
  purchaseDocument: PURCHASE_STATUS,
};

export const REPORT_PAYMENT_STATUS = SALES_PAYMENT_STATUS;

export const REPORT_STATUS_OPTIONS = {
  salesInvoice: [
    { label: "Draft", value: SALES_INVOICE_STATUS.DRAFT },
    { label: "Confirmed", value: SALES_INVOICE_STATUS.CONFIRMED },
    { label: "Cancelled", value: SALES_INVOICE_STATUS.CANCELLED },
  ],
  purchaseDocument: [
    { label: "Draft", value: PURCHASE_STATUS.DRAFT },
    { label: "Confirmed", value: PURCHASE_STATUS.CONFIRMED },
    { label: "Cancelled", value: PURCHASE_STATUS.CANCELLED },
    { label: "Converted", value: PURCHASE_STATUS.CONVERTED },
  ],
};

export const REPORT_PAYMENT_STATUS_OPTIONS = [
  { label: "Unpaid", value: SALES_PAYMENT_STATUS.UNPAID },
  { label: "Partial", value: SALES_PAYMENT_STATUS.PARTIAL },
  { label: "Paid", value: SALES_PAYMENT_STATUS.PAID },
];

// TODO(backend): confirm enum values in Swagger for movementType before mapping labels.
export const REPORT_MOVEMENT_TYPE = {};

// TODO(backend): confirm enum values in Swagger for voucherType before mapping labels.
export const REPORT_VOUCHER_TYPE = {};

export const getReportEnumLabel = (value, options = [], fallbackPrefix = "Value") => {
  const match = options.find((option) => Number(option.value) === Number(value));

  return match?.label ?? `${fallbackPrefix} ${value ?? "—"}`;
};
