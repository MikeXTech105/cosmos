export { default } from "./ProcurementSetupPage";
