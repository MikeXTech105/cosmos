export { default } from "./WalletsPage";
