export { default } from "./ExpenseCategoriesPage";
