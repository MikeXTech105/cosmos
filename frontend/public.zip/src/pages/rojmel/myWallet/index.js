export { default } from "./MyWalletPage";
