export { default } from "./CategoriesPage";
