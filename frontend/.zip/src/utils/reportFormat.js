const EMPTY_VALUE = "—";

const currencyFormatter = new Intl.NumberFormat("en-IN", {
  currency: "INR",
  maximumFractionDigits: 2,
  minimumFractionDigits: 2,
  style: "currency",
});

const numberFormatter = new Intl.NumberFormat("en-IN", {
  maximumFractionDigits: 2,
});

const percentFormatter = new Intl.NumberFormat("en-IN", {
  maximumFractionDigits: 2,
  style: "percent",
});

export const toReportNumber = (value) => {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  const numericValue = Number(value);

  return Number.isFinite(numericValue) ? numericValue : null;
};

export const formatCurrency = (value) => {
  const numericValue = toReportNumber(value);

  return numericValue === null ? EMPTY_VALUE : currencyFormatter.format(numericValue);
};

export const formatNumber = (value) => {
  const numericValue = toReportNumber(value);

  return numericValue === null ? EMPTY_VALUE : numberFormatter.format(numericValue);
};

export const formatQty = (value) => {
  const numericValue = toReportNumber(value);

  if (numericValue === null) {
    return EMPTY_VALUE;
  }

  return new Intl.NumberFormat("en-IN", {
    maximumFractionDigits: 3,
  }).format(numericValue);
};

export const formatDate = (value) => {
  if (!value) {
    return EMPTY_VALUE;
  }

  const date = value instanceof Date ? value : new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

export const formatPercent = (value) => {
  const numericValue = toReportNumber(value);

  if (numericValue === null) {
    return EMPTY_VALUE;
  }

  return percentFormatter.format(Math.abs(numericValue) > 1 ? numericValue / 100 : numericValue);
};

export const getNumericToneClassName = (value) => {
  const numericValue = toReportNumber(value);

  if (numericValue === null) {
    return "text-slate-400";
  }

  if (numericValue < 0) {
    return "text-red-600";
  }

  if (numericValue === 0) {
    return "text-slate-400";
  }

  return "text-slate-900";
};

export const formatCell = (value, column = {}) => {
  if (column.format === "currency") {
    return formatCurrency(value);
  }

  if (column.format === "date") {
    return formatDate(value);
  }

  if (column.format === "number") {
    return formatNumber(value);
  }

  if (column.format === "percent") {
    return formatPercent(value);
  }

  if (column.format === "qty" || column.format === "quantity") {
    return formatQty(value);
  }

  if (column.format === "pill" && column.pillMap) {
    return column.pillMap[Number(value)]?.label ?? String(value ?? EMPTY_VALUE);
  }

  return value === null || value === undefined || value === "" ? EMPTY_VALUE : String(value);
};

export const getReportValue = (row, key, fallback = EMPTY_VALUE) => {
  if (!row || !key) {
    return fallback;
  }

  return row[key] ?? row[String(key).charAt(0).toUpperCase() + String(key).slice(1)] ?? fallback;
};
