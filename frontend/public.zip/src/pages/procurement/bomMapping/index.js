export { default } from "./BomMappingPage";
