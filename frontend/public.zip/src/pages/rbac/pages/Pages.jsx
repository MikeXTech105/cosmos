export { default } from "./PagesPage";
