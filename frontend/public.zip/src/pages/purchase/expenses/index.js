export { default } from "./ExpensesPage";
