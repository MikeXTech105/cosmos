export { default } from "./DepartmentsPage";
