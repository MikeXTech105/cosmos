export { default } from "./ProcurementSettingsPage";
